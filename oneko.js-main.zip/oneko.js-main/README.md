# oneko.js

A hacky script I wrote to put a cat on my site.

The default image is `oneko.gif` in the same directory as the script. This can be changed by adding `data-cat="yourimage.png"` to your `<script>` tag.

https://adryd.com

implemented in a few different places
  - Userscript: https://openuserjs.org/scripts/sjehuda/Oneko_WebMate
  - Vencord: https://vencord.dev/plugins/oneko
  - Spicetify: https://github.com/kyrie25/spicetify-oneko
